// schemaData.js
const SchemaData = [
    // An array to store schema objects
  ];
  
  export default SchemaData;
  