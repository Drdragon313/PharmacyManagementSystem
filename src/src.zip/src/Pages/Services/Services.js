import React from 'react'

const Services = () => {
  return (
    <div>
        This is a services Page and it provides the services for file Uploading 
      
    </div>
  )
}

export default Services
